export interface ErrorMessage {
    statusCode: number;
    statusMessage: string;
}
