import {
    Component,
    OnInit
} from '@angular/core';

@Component({
    selector: 'secondary-layout',
    templateUrl: './secondary-layout.component.html',
    styleUrls: [ './secondary-layout.component.scss' ]
})
export class SecondaryLayoutComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
