import {
    Component,
    OnInit
} from '@angular/core';

@Component({
    selector: 'fourth-layout',
    templateUrl: './fourth-layout.component.html',
    styleUrls: [ './fourth-layout.component.scss' ]
})
export class FourthLayoutComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
