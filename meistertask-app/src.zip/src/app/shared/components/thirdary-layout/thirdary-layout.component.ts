import {
    Component,
    OnInit
} from '@angular/core';

@Component({
    selector: 'thirdary-layout',
    templateUrl: './thirdary-layout.component.html',
    styleUrls: [ './thirdary-layout.component.scss' ]
})
export class ThirdaryLayoutComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
