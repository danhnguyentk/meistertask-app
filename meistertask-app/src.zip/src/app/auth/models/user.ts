export interface User {
    id: number;
    workName: string;
    email: string;
    password: string;
}
