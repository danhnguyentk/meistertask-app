export interface Project {
    id: number;
    nameProject: string;
    descProject?: string;
}
