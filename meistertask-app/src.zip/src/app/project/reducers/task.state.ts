import { Task } from '../models/task';

export interface TaskState {
    taskList: Task[]
};
