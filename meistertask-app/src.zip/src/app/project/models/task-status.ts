export enum TaskStatus {
    OPEN = 1,
    INPROGRESS,
    DONE
}
